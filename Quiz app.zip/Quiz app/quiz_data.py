quiz_data = [
    {
        "question": "What is the name of the famous red racing car in the movie CARS?",
        "choices": ["Lightning McQueen", " Speedy Gonzalez", "Fast Freddie", "Zoom Zoom"],
        "answer": "Lightning McQueen"
    },
    {
        "question": "Which car brand has a logo with four rings?",
        "choices": ["BMW", "Audi", "Mercedes", "Ford"],
        "answer": "BMW"
    },
    {
        "question": " What kind of car transforms into a robot in the TRANSFORMERS movies?",
        "choices": ["Monster truck", "Sports car", "Muscle car", "Convertible"],
        "answer": "Sports car"
    },
    {
        "question": "What is the term used for an electric car that doesn't need gasoline?",
        "choices": ["Solar car", "Diesel car", "Hybrid cars", "Electric vehicle"],
        "answer": "Electric vehicle"
    }
    # Add more questions here
]